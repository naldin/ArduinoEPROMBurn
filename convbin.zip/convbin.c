#include <stdio.h>

#define BUFSZ 32769

int main (int argc, char **argv) {

    unsigned char buf[BUFSZ] = {0};
    size_t bytes = 0, i, readsz = sizeof buf;
    FILE *fp = argc > 1 ? fopen (argv[1], "rb") : stdin;
    FILE *out;
    out = fopen("out.txt", "w");

    if (!fp) {
        fprintf (stderr, "Falha ao abrir o arquivo '%s'.\n", argv[1]);
        return 1;
    }

    /* read/output BUFSZ bytes at a time */
    while ((bytes = fread (buf, sizeof *buf, readsz, fp)) == readsz) {

    }
    for (i = 0; i < bytes; i++) /* output final partial buf */

	fprintf(out, "0x%02X, ",buf[i]);

    if (fp != stdin){
        fclose (fp);
        fclose(out);
    }
    printf("Finalizado com sucesso\n\n");
    return 0;
}
